// === SISTEMA DE PLATAFORMA 2D ===
var platform2D = {
  canvas: null, ctx: null, running: false, animId: null,
  level: null, width: 800, height: 320,
  camera: { x: 0 }, player: null, cars: [], trafficLight: null,
  clouds: [], buildings: [], trees: [],
  keys: {}, touch: { left: false, right: false, jump: false },
  state: 'playing', frame: 0, groundY: 260
};

function renderPlatform2D(level) {
  var h = '<div class="platform2d-scene" id="platform2DScene">';
  h += '<canvas class="platform2d-canvas" id="platform2DCanvas"></canvas>';
  h += '<div class="platform2d-overlay" id="platform2DOverlay">';
  h += '<span class="big-emoji" id="p2dEmoji">⭐</span>';
  h += '<h4 id="p2dTitle">¡Bien hecho!</h4>';
  h += '<p id="p2dText"></p>';
  h += '<button class="btn btn-green" id="p2dRetry">🔄 Intentar de nuevo</button>';
  h += '<button class="btn btn-yellow" id="p2dContinue" style="display:none;margin-left:8px">▶️ Continuar</button>';
  h += '</div>';
  h += '</div>';
  h += '<p style="font-weight:700;margin-bottom:10px;font-size:1rem;text-align:center">' + level.instruction + '</p>';
  h += '<div class="platform2d-controls">';
  h += '<button class="platform2d-btn" id="p2dLeft">⬅️</button>';
  h += '<button class="platform2d-btn jump" id="p2dJump">⬆️</button>';
  h += '<button class="platform2d-btn" id="p2dRight">➡️</button>';
  h += '</div>';
  var tipText = level.scene === 'drive_stop' ? '⬅️ ➡️ Conducir · Frena en 🔴 ROJO y 🛑 ALTO' : '⬅️ ➡️ Moverse · ⬆️ Saltar · Cruza solo en 🟢 VERDE';
  h += '<p style="text-align:center;font-size:.8rem;color:#888">' + tipText + '</p>';
  return h;
}

function startPlatform2D(level) {
  stopPlatform2D();
  platform2D.level = level;
  platform2D.running = true;
  platform2D.state = 'playing';
  platform2D.frame = 0;
  platform2D.keys = {};
  platform2D.touch = { left: false, right: false, jump: false };
  platform2D.canvas = document.getElementById('platform2DCanvas');
  platform2D.ctx = platform2D.canvas.getContext('2d');
  platform2D.ctx.imageSmoothingEnabled = false;

  var sceneEl = document.getElementById('platform2DScene');
  if (sceneEl) {
    var rect = sceneEl.getBoundingClientRect();
    platform2D.width = Math.min(800, Math.max(320, rect.width));
    platform2D.height = Math.min(320, Math.max(200, rect.height));
    platform2D.canvas.width = platform2D.width;
    platform2D.canvas.height = platform2D.height;
    platform2D.groundY = platform2D.height - 60;
  } else {
    platform2D.width = 800;
    platform2D.height = 320;
    platform2D.canvas.width = 800;
    platform2D.canvas.height = 320;
    platform2D.groundY = 260;
  }

  platform2D.player = {
    x: 60, y: 0, vx: 0, vy: 0,
    width: 28, height: 40,
    onGround: false, facingRight: true,
    img: null, stoppedAtRed: false, crossedRoad: false, respectedStop: false
  };

  // Cargar sprite del personaje
  var img = new Image();
  img.onload = function() {
    platform2D.player.img = img;
  };
  img.onerror = function() {
    platform2D.player.img = null;
  };
  img.src = getPlayerImg();

  initPlatform2DWorld(level);
  setupPlatform2DControls();
  var overlay = document.getElementById('platform2DOverlay');
  if (overlay) overlay.classList.remove('active');
  platform2DLoop();
}

function initPlatform2DWorld(level) {
  platform2D.sceneType = level.scene || 'ped_cross';
  platform2D.isDriver = (platform2D.sceneType === 'drive_stop');
  platform2D.clouds = [];
  platform2D.buildings = [];
  platform2D.trees = [];
  platform2D.cars = [];

  for (var i = 0; i < 8; i++) {
    platform2D.clouds.push({
      x: Math.random() * 1600,
      y: 15 + Math.random() * 50,
      w: 50 + Math.random() * 70,
      speed: 0.08 + Math.random() * 0.15
    });
  }
  for (var i = 0; i < 16; i++) {
    platform2D.buildings.push({
      x: i * 100 + Math.random() * 40,
      w: 55 + Math.random() * 55,
      h: 70 + Math.random() * 110,
      color: ['#1a237e','#283593','#0d47a1','#1565c0','#6a1b9a','#4527a0'][Math.floor(Math.random()*6)]
    });
  }
  for (var i = 0; i < 10; i++) {
    platform2D.trees.push({
      x: 120 + i * 160 + Math.random() * 50,
      h: 35 + Math.random() * 30
    });
  }

  if (platform2D.isDriver) {
    platform2D.roadStart = 80;
    platform2D.roadEnd = 720;
    platform2D.trafficLight = { x: 380, state: 'red', timer: 0, phaseDuration: 1320, graceTimer: 0, hasStopSign: true, stopSignX: 320 };
    platform2D.finishX = 780;
    platform2D.player.width = 52;
    platform2D.player.height = 28;
    platform2D.player.y = platform2D.groundY - platform2D.player.height;
    platform2D.player.x = 40;
    platform2D.player.onGround = true;
    platform2D.player.vx = 0; platform2D.player.vy = 0;
  } else {
    platform2D.roadStart = 280;
    platform2D.roadEnd = 520;
    platform2D.trafficLight = { x: 340, state: 'red', timer: 0, phaseDuration: 1320, graceTimer: 0, hasStopSign: false };
    platform2D.finishX = 760;
    platform2D.player.width = 28;
    platform2D.player.height = 40;
    platform2D.player.y = platform2D.groundY - platform2D.player.height;
    platform2D.player.x = 40;
    platform2D.player.onGround = true;
    platform2D.player.vx = 0; platform2D.player.vy = 0;
  }

  platform2D.player.facingRight = true;
  platform2D.player.stoppedAtRed = false;
  platform2D.player.crossedRoad = false;
  platform2D.player.respectedStop = false;
  platform2D.camera.x = 0;
}

function setupPlatform2DControls() {
  if (platform2D._keyDownHandler) {
    document.removeEventListener('keydown', platform2D._keyDownHandler);
    document.removeEventListener('keyup', platform2D._keyUpHandler);
  }
  platform2D._keyDownHandler = function(e) {
    platform2D.keys[e.key] = true;
    if (['ArrowLeft','ArrowRight','ArrowUp','ArrowDown',' '].indexOf(e.key) >= 0) {
      e.preventDefault();
    }
  };
  platform2D._keyUpHandler = function(e) {
    platform2D.keys[e.key] = false;
  };
  document.addEventListener('keydown', platform2D._keyDownHandler);
  document.addEventListener('keyup', platform2D._keyUpHandler);

  var btnLeft = document.getElementById('p2dLeft');
  var btnRight = document.getElementById('p2dRight');
  var btnJump = document.getElementById('p2dJump');

  [btnLeft, btnRight, btnJump].forEach(function(btn) {
    if (!btn) return;
    var newBtn = btn.cloneNode(true);
    btn.parentNode.replaceChild(newBtn, btn);
  });
  btnLeft = document.getElementById('p2dLeft');
  btnRight = document.getElementById('p2dRight');
  btnJump = document.getElementById('p2dJump');

  function setTouch(el, prop) {
    if (!el) return;
    el.addEventListener('touchstart', function(e) { e.preventDefault(); platform2D.touch[prop] = true; }, {passive:false});
    el.addEventListener('touchend', function(e) { e.preventDefault(); platform2D.touch[prop] = false; }, {passive:false});
    el.addEventListener('touchcancel', function(e) { e.preventDefault(); platform2D.touch[prop] = false; }, {passive:false});
    el.addEventListener('mousedown', function() { platform2D.touch[prop] = true; });
    el.addEventListener('mouseup', function() { platform2D.touch[prop] = false; });
    el.addEventListener('mouseleave', function() { platform2D.touch[prop] = false; });
  }
  setTouch(btnLeft, 'left');
  setTouch(btnRight, 'right');
  setTouch(btnJump, 'jump');

  var retryBtn = document.getElementById('p2dRetry');
  if (retryBtn) {
    retryBtn.onclick = function() {
      document.getElementById('platform2DOverlay').classList.remove('active');
      startPlatform2D(platform2D.level);
    };
  }
  var continueBtn = document.getElementById('p2dContinue');
  if (continueBtn) {
    continueBtn.onclick = function() {
      document.getElementById('platform2DOverlay').classList.remove('active');
      completeLevel();
    };
  }
}

function platform2DLoop() {
  if (!platform2D.running) return;
  platform2D.frame++;
  updatePlatform2D();
  drawPlatform2D();
  platform2D.animId = requestAnimationFrame(platform2DLoop);
}

function updatePlatform2D() {
  if (platform2D.state !== 'playing') return;
  var p = platform2D.player;
  var groundY = platform2D.groundY;
  var moveLeft = platform2D.keys['ArrowLeft'] || platform2D.keys['a'] || platform2D.touch.left;
  var moveRight = platform2D.keys['ArrowRight'] || platform2D.keys['d'] || platform2D.touch.right;
  var doJump = platform2D.keys['ArrowUp'] || platform2D.keys[' '] || platform2D.touch.jump;
  var roadStart = platform2D.roadStart;
  var roadEnd = platform2D.roadEnd;
  var tl = platform2D.trafficLight;

  tl.timer++;
  var phase = tl.timer % tl.phaseDuration;
  // Ciclo de 22 segundos (1320 frames a 60fps)
  // Para CONDUCTOR: rojo(7s) -> amarillo(2s) -> verde(10s) -> gracia(3s)
  // Para PEATON: verde(7s) -> amarillo(2s) -> rojo(10s) -> gracia(3s)
  var redEnd = 420;      // 7 segundos
  var yellowEnd = 540;   // +2s (total 9s)
  var greenEnd = 1140;   // +10s (total 19s)
  // gracia: 180 frames = 3s (1140-1320)

  if (platform2D.isDriver) {
    if (phase < redEnd) { tl.state = 'red'; tl.graceTimer = 0; }
    else if (phase < yellowEnd) { tl.state = 'yellow'; tl.graceTimer = 0; }
    else if (phase < greenEnd) { tl.state = 'green'; tl.graceTimer = 0; }
    else { tl.state = 'green'; tl.graceTimer = greenEnd + 180 - phase; }
  } else {
    if (phase < redEnd) { tl.state = 'red'; tl.graceTimer = 0; }
    else if (phase < yellowEnd) { tl.state = 'yellow'; tl.graceTimer = 0; }
    else if (phase < greenEnd) { tl.state = 'green'; tl.graceTimer = 0; }
    else { tl.state = 'green'; tl.graceTimer = greenEnd + 180 - phase; }
  }

  if (platform2D.isDriver) {
    var maxSpeed = 3.5;
    var accel = 0.3;
    var friction = 0.92;

    if (moveLeft) { p.vx -= accel; p.facingRight = false; }
    else if (moveRight) { p.vx += accel; p.facingRight = true; }
    else { p.vx *= friction; }
    if (Math.abs(p.vx) > maxSpeed) p.vx = (p.vx > 0 ? maxSpeed : -maxSpeed);

    p.y = groundY - p.height;
    p.onGround = true;
    p.vy = 0;

    // === REGLAS DEL SEMAFORO Y ALTO ===
    var stopSignX = tl.stopSignX || 320;
    var isBeforeStop = p.x + p.width < stopSignX;
    var isAtStop = Math.abs((p.x + p.width/2) - stopSignX) < 40;
    var isAfterStop = p.x > stopSignX;

    // Si intentas pasar la señal de alto en ROJO -> pierdes
    if (isAfterStop && tl.state === 'red') {
      platform2D.state = 'lost';
      showPlatform2DOverlay('🛑', '¡Pasaste en ROJO!', 
        'El semaforo esta en 🔴 ROJO. Debes DETENERTE en la señal de 🛑 ALTO y esperar a 🟢 VERDE para pasar.', true);
      return;
    }

    // Si estas en el alto y el semaforo esta en ROJO, debes detenerte
    if (isAtStop && tl.state === 'red' && Math.abs(p.vx) > 0.3) {
      platform2D.state = 'lost';
      showPlatform2DOverlay('🛑', '¡No te detuviste en el ALTO!', 
        'Debes detenerte COMPLETAMENTE en la señal de 🛑 ALTO cuando el semaforo esta en 🔴 ROJO.', true);
      return;
    }

    // Registro: se detuvo correctamente en el alto durante ROJO
    if (isAtStop && tl.state === 'red' && Math.abs(p.vx) < 0.2) {
      p.stoppedAtRed = true;
    }

    p.x += p.vx;
    if (p.x < 0) { p.x = 0; p.vx = 0; }
    if (p.x > platform2D.finishX) p.x = platform2D.finishX;

    // Autos decorativos en el mismo carril (misma altura que jugador)
    if (platform2D.frame % 100 === 0 && Math.random() < 0.6) {
      var carY = groundY - 28;  // MISMA ALTURA que el auto del jugador
      var carSpeed = 1.5 + Math.random() * 1.5;
      var fromLeft = Math.random() < 0.5;
      platform2D.cars.push({
        x: fromLeft ? -80 : 900,
        y: carY,
        w: 50, h: 22,
        vx: fromLeft ? carSpeed : -carSpeed,
        originalSpeed: carSpeed,
        color: ['#e53935','#1e88e5','#fdd835','#43a047','#8e24aa'][Math.floor(Math.random()*5)],
        respectsLight: true,
        isDecorative: true  // NO colisionan con el jugador
      });
    }

    for (var i = platform2D.cars.length - 1; i >= 0; i--) {
      var car = platform2D.cars[i];
      // Autos decorativos: se detienen en ROJO, no colisionan con jugador
      if (car.respectsLight && tl.state === 'red') {
        car.vx = 0;
      } else if (car.respectsLight && tl.state === 'yellow') {
        if (Math.abs(car.vx) > (car.originalSpeed||Math.abs(car.vx))*0.5) car.vx *= 0.5;
      }
      car.x += car.vx;
      if (car.x < -100 || car.x > 950) { platform2D.cars.splice(i, 1); continue; }
      // Los autos decorativos NO atropellan al jugador
      if (!car.isDecorative &&
          p.x < car.x + car.w && p.x + p.width > car.x &&
          p.y < car.y + car.h && p.y + p.height > car.y) {
        platform2D.state = 'lost';
        showPlatform2DOverlay('💥', '¡Choque!', 
          'Chocaste con otro vehiculo. Manten la distancia de seguridad y respeta las senales de transito.', true);
        return;
      }
    }

    if (p.x + p.width >= platform2D.finishX - 10) {
      // Victoria: si llegaste a la meta sin perder, significa que respetaste el ALTO
      platform2D.state = 'won';
      var msg = tl.hasStopSign 
        ? 'Excelente conducción. Respetaste el semáforo en 🔴 ROJO, frenaste en 🛑 ALTO, y llegaste a la meta con seguridad. ¡Buen trabajo!'
        : 'Excelente conducción. Respetaste el semáforo y llegaste a la meta con seguridad. ¡Recuerda siempre frenar en rojo!';
      showPlatform2DOverlay('⭐', '¡Llegaste a la meta!', msg, false);
      return;
    }

  } else {
    if (moveLeft) { p.vx = -2.2; p.facingRight = false; }
    else if (moveRight) { p.vx = 2.2; p.facingRight = true; }
    else { p.vx *= 0.7; }
    if (doJump && p.onGround) { p.vy = -8.5; p.onGround = false; }
    p.vy += 0.45;
    p.x += p.vx;
    p.y += p.vy;
    if (p.y + p.height >= groundY) { p.y = groundY - p.height; p.vy = 0; p.onGround = true; }
    if (p.x < 0) p.x = 0;
    if (p.x > 850) p.x = 850;

    var inRoad = (p.x + p.width > roadStart + 5 && p.x < roadEnd - 5);
    var onSidewalkRight = (p.x >= roadEnd - 10);

    if (inRoad && tl.state !== 'green') {
      platform2D.state = 'lost';
      showPlatform2DOverlay('🔴', '¡Cruzaste en ROJO!', 
        'El semáforo estaba en 🔴 ROJO para los peatones. Debes esperar a que esté en 🟢 VERDE para cruzar la calle. La paciencia salva vidas.', true);
      return;
    }

    if (inRoad && tl.state !== 'green') {
      for (var i = 0; i < platform2D.cars.length; i++) {
        var car = platform2D.cars[i];
        if (p.x < car.x + car.w && p.x + p.width > car.x &&
            p.y < car.y + car.h && p.y + p.height > car.y) {
          platform2D.state = 'lost';
          showPlatform2DOverlay('💥', '¡Te atropelló un auto!', 
            'Un auto te golpeó al cruzar. El semáforo estaba en 🔴 ROJO para peatones. Espera a 🟢 VERDE para cruzar con seguridad.', true);
          return;
        }
      }
    }

    if (platform2D.frame % 80 === 0 && Math.random() < 0.65) {
      var fromLeft = Math.random() < 0.5;
      var carY = groundY - 26;
      var carSpeed = 2 + Math.random() * 2;
      platform2D.cars.push({
        x: fromLeft ? -60 : 880,
        y: carY,
        w: 48, h: 22,
        vx: fromLeft ? carSpeed : -carSpeed,
        color: ['#e53935','#1e88e5','#fdd835','#43a047'][Math.floor(Math.random()*4)],
        respectsLight: true
      });
    }

    for (var i = platform2D.cars.length - 1; i >= 0; i--) {
      var car = platform2D.cars[i];
      var carMoving = true;
      if (car.respectsLight) {
        if (tl.state === 'green') {
          // VERDE peatonal: autos DETENIDOS (peaton cruza con seguridad)
          car.vx = 0;
          carMoving = false;
        } else if (tl.state === 'yellow') {
          if (Math.abs(car.vx) > (car.originalSpeed||Math.abs(car.vx))*0.5) car.vx *= 0.5;
        }
      }
      car.x += car.vx;
      if (car.x < -80 || car.x > 920) { platform2D.cars.splice(i, 1); continue; }
    }

    if (p.x >= platform2D.finishX && onSidewalkRight) {
      platform2D.state = 'won';
      showPlatform2DOverlay('⭐', '¡Cruzaste con seguridad!', 
        'Excelente trabajo. Esperaste el semáforo en 🟢 VERDE, observaste que no había autos cerca, y cruzaste la calle de manera segura. ¡Siempre usa el paso peatonal!', false);
      return;
    }
  }

  platform2D.camera.x = p.x - platform2D.width * 0.3;
  if (platform2D.camera.x < 0) platform2D.camera.x = 0;
  if (platform2D.camera.x > 900 - platform2D.width) platform2D.camera.x = 900 - platform2D.width;
}


// === SISTEMA DE ANIMACIÓN DEL PERSONAJE PRINCIPAL (Canvas-drawn) ===
// Personaje estilo chibi: gorra azul/blanca con semáforo, chamarra amarilla/azul, mochila, ojos grandes

function getPlayerSpriteFrame() {
  var p = platform2D.player;
  var state = platform2D.state;
  var frame = platform2D.frame;

  if (state === 'lost') return { type: 'hurt', frame: 0 };
  if (state === 'won') return { type: 'victory', frame: Math.floor(frame / 8) % 2 };
  if (!p.onGround) return { type: 'jump', frame: Math.min(Math.floor(Math.abs(p.vy)), 3) };
  if (Math.abs(p.vx) > 2.5) return { type: 'run', frame: Math.floor(frame / 4) % 3 };
  if (Math.abs(p.vx) > 0.5) return { type: 'walk', frame: Math.floor(frame / 6) % 4 };
  return { type: 'idle', frame: Math.floor(frame / 15) % 2 };
}

function drawAnimatedPlayer(ctx, x, y, w, h, frameInfo) {
  var f = frameInfo;
  var p = platform2D.player;
  var cx = x + w/2;
  var cy = y + h/2;
  var scale = Math.min(w, h) / 48;

  ctx.save();
  ctx.translate(cx, cy);
  // Si va a la izquierda, voltear todo el personaje horizontalmente
  if (!p.facingRight) ctx.scale(-1, 1);
  ctx.scale(scale, scale);

  // === VARIABLES DE ANIMACIÓN ===
  var bounce = 0, armSwing = 0, legSwing1 = 0, legSwing2 = 0;
  var bodyTilt = 0, headTilt = 0, hairBounce = 0;

  if (f.type === 'idle') {
    bounce = f.frame === 0 ? 0 : -1;
    armSwing = 0;
    legSwing1 = 0; legSwing2 = 0;
  } else if (f.type === 'walk') {
    bounce = [0, -2, 0, -2][f.frame];
    armSwing = [0, -8, 0, 8][f.frame];
    legSwing1 = [0, 6, 0, -6][f.frame];  // pierna trasera
    legSwing2 = [0, -6, 0, 6][f.frame];  // pierna delantera
  } else if (f.type === 'run') {
    bounce = [0, -3, -1][f.frame];
    armSwing = [0, -12, 10][f.frame];
    legSwing1 = [0, 10, -10][f.frame];
    legSwing2 = [0, -10, 10][f.frame];
    bodyTilt = 8;
    hairBounce = 2;
  } else if (f.type === 'jump') {
    bounce = -5;
    armSwing = -14;
    legSwing1 = 8;
    legSwing2 = -4;
    hairBounce = 3;
  } else if (f.type === 'hurt') {
    bounce = 4;
    bodyTilt = -20;
    headTilt = -15;
    armSwing = 0;
    legSwing1 = 2; legSwing2 = -2;
  } else if (f.type === 'victory') {
    bounce = f.frame === 0 ? -5 : -2;
    armSwing = -16;
    legSwing1 = -4; legSwing2 = 4;
    hairBounce = 2;
  }

  var by = bounce;

  // === MOCHILA (detrás del cuerpo, vista lateral) ===
  ctx.fillStyle = '#1a1a2e';
  ctx.beginPath();
  ctx.roundRect(-16, by - 10, 10, 22, 3);
  ctx.fill();
  // Bolsillo mochila
  ctx.fillStyle = '#0d1b2a';
  ctx.fillRect(-14, by - 4, 6, 10);
  // Triángulo amarillo de advertencia
  ctx.fillStyle = '#ffd600';
  ctx.beginPath();
  ctx.moveTo(-11, by + 2);
  ctx.lineTo(-8, by + 7);
  ctx.lineTo(-14, by + 7);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = '#000';
  ctx.font = 'bold 5px Arial';
  ctx.fillText('!', -12, by + 6);
  // Correas de mochila
  ctx.strokeStyle = '#333';
  ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(-13, by - 8); ctx.lineTo(-8, by - 12); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(-13, by + 8); ctx.lineTo(-8, by + 4); ctx.stroke();

  // === PIERNA TRASERA (izquierda, detrás) ===
  ctx.fillStyle = '#263238';
  if (f.type === 'walk' || f.type === 'run') {
    ctx.save();
    ctx.translate(-2, by + 10);
    ctx.rotate(legSwing1 * Math.PI / 180);
    ctx.fillRect(-3, 0, 6, 12);
    // Zapatilla trasera
    ctx.fillStyle = '#1565c0';
    ctx.fillRect(-4, 10, 9, 5);
    ctx.fillStyle = '#fff';
    ctx.fillRect(-4, 13, 9, 2);
    ctx.restore();
  } else if (f.type === 'jump') {
    ctx.save();
    ctx.translate(-2, by + 8);
    ctx.rotate(legSwing1 * Math.PI / 180);
    ctx.fillRect(-3, 0, 6, 10);
    ctx.fillStyle = '#1565c0';
    ctx.fillRect(-4, 8, 9, 5);
    ctx.fillStyle = '#fff';
    ctx.fillRect(-4, 11, 9, 2);
    ctx.restore();
  } else if (f.type === 'hurt') {
    ctx.fillRect(-4, by + 12, 6, 10);
    ctx.fillStyle = '#1565c0';
    ctx.fillRect(-5, by + 20, 8, 4);
    ctx.fillStyle = '#fff';
    ctx.fillRect(-5, by + 22, 8, 2);
  } else {
    ctx.fillRect(-3, by + 10, 6, 12);
    ctx.fillStyle = '#1565c0';
    ctx.fillRect(-4, by + 20, 8, 5);
    ctx.fillStyle = '#fff';
    ctx.fillRect(-4, by + 23, 8, 2);
  }

  // === TORSO (vista lateral) ===
  ctx.save();
  ctx.rotate(bodyTilt * Math.PI / 180);

  // Cuerpo principal
  ctx.fillStyle = '#1976d2';
  ctx.beginPath();
  ctx.roundRect(-8, by - 8, 16, 20, 3);
  ctx.fill();

  // Franja amarilla reflectante
  ctx.fillStyle = '#ffd600';
  ctx.fillRect(-7, by - 2, 14, 7);
  ctx.fillStyle = '#fff9c4';
  ctx.fillRect(-7, by - 2, 14, 2);

  // Cremallera lateral
  ctx.fillStyle = '#0d47a1';
  ctx.fillRect(-1, by - 8, 2, 20);
  // Dientes de cremallera
  ctx.fillStyle = '#64b5f6';
  for (var z = by - 6; z < by + 10; z += 3) {
    ctx.fillRect(-1.5, z, 3, 1.5);
  }

  // Bolsillo lateral
  ctx.fillStyle = '#1565c0';
  ctx.fillRect(2, by + 2, 5, 6);
  ctx.strokeStyle = '#0d47a1';
  ctx.lineWidth = 1;
  ctx.strokeRect(2, by + 2, 5, 6);

  // Parche de peatón en la manga (como en la imagen)
  ctx.fillStyle = '#fff';
  ctx.beginPath(); ctx.arc(-10, by - 2, 4, 0, Math.PI*2); ctx.fill();
  ctx.strokeStyle = '#1976d2';
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.fillStyle = '#1976d2';
  ctx.beginPath();
  ctx.moveTo(-10, by - 4); ctx.lineTo(-8, by - 1); ctx.lineTo(-12, by - 1);
  ctx.closePath(); ctx.fill();
  ctx.fillRect(-11, by - 1, 2, 3);

  // === BRAZO (vista lateral) ===
  ctx.fillStyle = '#1976d2';
  if (f.type === 'victory') {
    ctx.save();
    ctx.translate(0, by - 6);
    ctx.rotate(-50 * Math.PI / 180);
    ctx.fillRect(-3, -12, 7, 14);
    ctx.restore();
  } else if (f.type === 'hurt') {
    ctx.fillRect(-3, by + 2, 7, 10);
  } else if (f.type === 'jump') {
    ctx.save();
    ctx.translate(0, by - 4);
    ctx.rotate(-30 * Math.PI / 180);
    ctx.fillRect(-3, -12, 7, 14);
    ctx.restore();
  } else {
    ctx.save();
    ctx.translate(0, by - 2);
    ctx.rotate(armSwing * Math.PI / 180);
    ctx.fillRect(-3, -12, 7, 14);
    ctx.restore();
  }

  // Mano/Guante
  ctx.fillStyle = '#333';
  if (f.type === 'victory') {
    ctx.beginPath(); ctx.arc(8, by - 16, 4, 0, Math.PI*2); ctx.fill();
  } else if (f.type === 'hurt') {
    ctx.beginPath(); ctx.arc(1, by + 10, 4, 0, Math.PI*2); ctx.fill();
  } else if (f.type === 'jump') {
    ctx.beginPath(); ctx.arc(5, by - 14, 4, 0, Math.PI*2); ctx.fill();
  } else {
    ctx.save();
    ctx.translate(0, by - 2);
    ctx.rotate(armSwing * Math.PI / 180);
    ctx.beginPath(); ctx.arc(0.5, -13, 4, 0, Math.PI*2); ctx.fill();
    ctx.restore();
  }

  // === CUELLO ===
  ctx.fillStyle = '#ffccbc';
  ctx.fillRect(-3, by - 12, 6, 5);

  // === CABEZA (vista lateral) ===
  ctx.save();
  ctx.rotate(headTilt * Math.PI / 180);
  var hy = by - 18;

  // Oreja (solo la derecha visible en perfil)
  ctx.fillStyle = '#ffccbc';
  ctx.beginPath(); ctx.arc(-10, hy + 1, 3.5, 0, Math.PI*2); ctx.fill();
  ctx.fillStyle = '#ffab91';
  ctx.beginPath(); ctx.arc(-10, hy + 1, 2, 0, Math.PI*2); ctx.fill();

  // Cara (forma ovalada de perfil)
  ctx.fillStyle = '#ffccbc';
  ctx.beginPath();
  ctx.ellipse(-2, hy, 10, 11, 0, 0, Math.PI*2);
  ctx.fill();

  // Nariz (vista lateral)
  ctx.fillStyle = '#ffab91';
  ctx.beginPath(); ctx.arc(6, hy + 2, 2.5, 0, Math.PI*2); ctx.fill();

  // Pelo (vista lateral)
  ctx.fillStyle = '#5d4037';
  // Parte superior
  ctx.beginPath(); ctx.arc(-3, hy - 4, 10, Math.PI * 0.8, Math.PI * 1.8); ctx.fill();
  // Flequillo
  ctx.fillRect(-10, hy - 8, 14, 5);
  ctx.beginPath(); ctx.moveTo(-10, hy - 8); ctx.lineTo(-6, hy - 2); ctx.lineTo(-2, hy - 8); ctx.fill();
  ctx.beginPath(); ctx.moveTo(0, hy - 8); ctx.lineTo(4, hy - 3); ctx.lineTo(6, hy - 8); ctx.fill();
  // Pelo detrás
  ctx.fillRect(-12, hy - 4, 5, 10);
  // Mechón moviéndose al correr/saltar
  if (hairBounce > 0) {
    ctx.save();
    ctx.translate(-12, hy - 2);
    ctx.rotate(hairBounce * Math.PI / 180);
    ctx.fillRect(-4, -2, 5, 8);
    ctx.restore();
  }

  // === GORRA (vista lateral) ===
  // Copa
  ctx.fillStyle = '#fff';
  ctx.beginPath();
  ctx.arc(-2, hy - 10, 9, Math.PI * 0.7, Math.PI * 1.7);
  ctx.fill();
  // Panel azul lateral
  ctx.fillStyle = '#1976d2';
  ctx.beginPath();
  ctx.arc(2, hy - 10, 7, Math.PI * 0.8, Math.PI * 1.6);
  ctx.fill();
  // Visera
  ctx.fillStyle = '#1565c0';
  ctx.beginPath();
  ctx.ellipse(7, hy - 8, 7, 4, 0, 0, Math.PI);
  ctx.fill();
  ctx.fillStyle = '#0d47a1';
  ctx.beginPath();
  ctx.ellipse(7, hy - 7, 7, 2, 0, 0, Math.PI);
  ctx.fill();
  // Botón de la gorra
  ctx.fillStyle = '#1565c0';
  ctx.beginPath(); ctx.arc(-2, hy - 19, 2, 0, Math.PI*2); ctx.fill();
  // Semáforo en la gorra (lateral)
  ctx.fillStyle = '#333';
  ctx.fillRect(-1, hy - 18, 3, 7);
  ctx.fillStyle = '#ff1744';
  ctx.beginPath(); ctx.arc(0.5, hy - 16, 1.2, 0, Math.PI*2); ctx.fill();
  ctx.fillStyle = '#ffd600';
  ctx.beginPath(); ctx.arc(0.5, hy - 13, 1.2, 0, Math.PI*2); ctx.fill();
  ctx.fillStyle = '#00e676';
  ctx.beginPath(); ctx.arc(0.5, hy - 10, 1.2, 0, Math.PI*2); ctx.fill();

  // === OJO (vista lateral, grande estilo anime) ===
  if (f.type === 'hurt') {
    // Ojo cerrado/X
    ctx.strokeStyle = '#d32f2f';
    ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(2, hy - 2); ctx.lineTo(6, hy + 2); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(6, hy - 2); ctx.lineTo(2, hy + 2); ctx.stroke();
  } else {
    // Ojo grande
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    ctx.ellipse(4, hy - 1, 5, 6, 0, 0, Math.PI*2);
    ctx.fill();
    // Iris marrón
    ctx.fillStyle = '#5d4037';
    ctx.beginPath(); ctx.arc(5, hy, 3.5, 0, Math.PI*2); ctx.fill();
    // Pupila
    ctx.fillStyle = '#000';
    ctx.beginPath(); ctx.arc(5.5, hy, 2, 0, Math.PI*2); ctx.fill();
    // Brillo
    ctx.fillStyle = '#fff';
    ctx.beginPath(); ctx.arc(6, hy - 2, 1.5, 0, Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.arc(4, hy + 1, 1, 0, Math.PI*2); ctx.fill();
    // Pestañas
    ctx.strokeStyle = '#5d4037';
    ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(-1, hy - 4); ctx.quadraticCurveTo(4, hy - 8, 9, hy - 4); ctx.stroke();
  }

  // Cejas
  ctx.strokeStyle = '#5d4037';
  ctx.lineWidth = 1.2;
  if (f.type === 'hurt') {
    ctx.beginPath(); ctx.moveTo(0, hy - 6); ctx.lineTo(6, hy - 5); ctx.stroke();
  } else if (f.type === 'victory') {
    ctx.beginPath(); ctx.moveTo(0, hy - 7); ctx.quadraticCurveTo(4, hy - 9, 8, hy - 7); ctx.stroke();
  } else {
    ctx.beginPath(); ctx.moveTo(0, hy - 7); ctx.quadraticCurveTo(4, hy - 8, 8, hy - 7); ctx.stroke();
  }

  // Boca (vista lateral)
  ctx.strokeStyle = '#d84315';
  ctx.lineWidth = 1;
  if (f.type === 'hurt') {
    ctx.beginPath(); ctx.arc(5, hy + 7, 3, 0, Math.PI, false); ctx.stroke();
  } else if (f.type === 'victory') {
    ctx.beginPath(); ctx.arc(5, hy + 6, 4, 0, Math.PI, false); ctx.stroke();
    ctx.fillStyle = '#fff';
    ctx.fillRect(3, hy + 6, 4, 2);
  } else {
    ctx.beginPath(); ctx.arc(5, hy + 6, 2.5, 0, Math.PI, false); ctx.stroke();
  }

  // Mejilla
  if (f.type !== 'hurt') {
    ctx.fillStyle = 'rgba(255, 100, 100, 0.3)';
    ctx.beginPath(); ctx.arc(0, hy + 4, 3, 0, Math.PI*2); ctx.fill();
  }

  ctx.restore(); // headTilt
  ctx.restore(); // bodyTilt

  // === PIERNA DELANTERA (derecha, adelante) ===
  ctx.fillStyle = '#37474f';
  if (f.type === 'walk' || f.type === 'run') {
    ctx.save();
    ctx.translate(4, by + 10);
    ctx.rotate(legSwing2 * Math.PI / 180);
    ctx.fillRect(-3, 0, 6, 12);
    // Zapatilla delantera
    ctx.fillStyle = '#1976d2';
    ctx.fillRect(-4, 10, 9, 5);
    ctx.fillStyle = '#fff';
    ctx.fillRect(-4, 13, 9, 2);
    // Detalle zapatilla
    ctx.fillStyle = '#ffd600';
    ctx.fillRect(-2, 11, 5, 1.5);
    ctx.restore();
  } else if (f.type === 'jump') {
    ctx.save();
    ctx.translate(4, by + 6);
    ctx.rotate(legSwing2 * Math.PI / 180);
    ctx.fillRect(-3, 0, 6, 12);
    ctx.fillStyle = '#1976d2';
    ctx.fillRect(-4, 10, 9, 5);
    ctx.fillStyle = '#fff';
    ctx.fillRect(-4, 13, 9, 2);
    ctx.fillStyle = '#ffd600';
    ctx.fillRect(-2, 11, 5, 1.5);
    ctx.restore();
  } else if (f.type === 'hurt') {
    ctx.fillRect(2, by + 12, 6, 10);
    ctx.fillStyle = '#1976d2';
    ctx.fillRect(1, by + 20, 8, 4);
    ctx.fillStyle = '#fff';
    ctx.fillRect(1, by + 22, 8, 2);
  } else {
    ctx.fillRect(3, by + 10, 6, 12);
    ctx.fillStyle = '#1976d2';
    ctx.fillRect(2, by + 20, 8, 5);
    ctx.fillStyle = '#fff';
    ctx.fillRect(2, by + 23, 8, 2);
    ctx.fillStyle = '#ffd600';
    ctx.fillRect(4, by + 21, 4, 1.5);
  }

  ctx.restore(); // main transform
}
function drawPlatform2D() {
  var ctx = platform2D.ctx;
  var camX = platform2D.camera.x;
  var w = platform2D.width;
  var h = platform2D.height;
  var groundY = platform2D.groundY;

  var skyGrad = ctx.createLinearGradient(0, 0, 0, h);
  skyGrad.addColorStop(0, '#0d1b2a');
  skyGrad.addColorStop(0.35, '#1b2838');
  skyGrad.addColorStop(0.35, '#2d4a3e');
  skyGrad.addColorStop(1, '#1b5e20');
  ctx.fillStyle = skyGrad;
  ctx.fillRect(0, 0, w, h);

  ctx.fillStyle = 'rgba(255,255,255,0.6)';
  for (var i = 0; i < 20; i++) {
    var sx = ((i * 73 + 50) % w);
    var sy = ((i * 37 + 20) % (groundY * 0.4));
    ctx.fillRect(sx, sy, 1.5, 1.5);
  }

  ctx.fillStyle = 'rgba(255,255,255,0.12)';
  platform2D.clouds.forEach(function(cloud) {
    var x = ((cloud.x - camX * 0.05) % (w + 300));
    if (x < -150) x += w + 300;
    ctx.beginPath();
    ctx.ellipse(x, cloud.y, cloud.w/2, cloud.w/5, 0, 0, Math.PI*2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(x + cloud.w*0.3, cloud.y - 5, cloud.w*0.35, cloud.w*0.18, 0, 0, Math.PI*2);
    ctx.fill();
  });

  platform2D.buildings.forEach(function(b) {
    var x = b.x - camX * 0.15;
    while (x < -150) x += 1600;
    while (x > w + 150) x -= 1600;
    if (x > -150 && x < w + 150) {
      ctx.fillStyle = b.color;
      ctx.fillRect(x, groundY - b.h, b.w, b.h);
      ctx.fillStyle = 'rgba(255,255,150,0.25)';
      for (var wy = groundY - b.h + 10; wy < groundY - 10; wy += 16) {
        for (var wx = x + 8; wx < x + b.w - 8; wx += 14) {
          if ((Math.floor(wy + wx) % 5) === 0) ctx.fillRect(wx, wy, 8, 10);
        }
      }
      ctx.fillStyle = 'rgba(0,0,0,0.2)';
      ctx.fillRect(x, groundY - b.h, b.w, 3);
    }
  });

  platform2D.trees.forEach(function(t) {
    var x = t.x - camX * 0.4;
    while (x < -60) x += 1600;
    while (x > w + 60) x -= 1600;
    if (x > -60 && x < w + 60) {
      ctx.fillStyle = '#4e342e';
      ctx.fillRect(x - 4, groundY - t.h, 8, t.h);
      ctx.fillStyle = '#1b5e20';
      ctx.beginPath();
      ctx.arc(x, groundY - t.h - 2, 18, 0, Math.PI*2);
      ctx.fill();
      ctx.fillStyle = '#2e7d32';
      ctx.beginPath();
      ctx.arc(x - 7, groundY - t.h + 2, 14, 0, Math.PI*2);
      ctx.fill();
      ctx.fillStyle = '#388e3c';
      ctx.beginPath();
      ctx.arc(x + 7, groundY - t.h + 2, 12, 0, Math.PI*2);
      ctx.fill();
    }
  });

  ctx.fillStyle = '#33691e';
  ctx.fillRect(0, groundY, w, h - groundY);
  ctx.fillStyle = '#558b2f';
  ctx.fillRect(0, groundY, w, 4);

  var roadStart = platform2D.roadStart - camX;
  var roadEnd = platform2D.roadEnd - camX;

  ctx.fillStyle = '#78909c';
  ctx.fillRect(roadStart - 40, groundY - 6, 40, 6);
  ctx.strokeStyle = '#cfd8dc';
  ctx.setLineDash([6, 6]);
  ctx.beginPath();
  ctx.moveTo(roadStart - 40, groundY - 3);
  ctx.lineTo(roadStart, groundY - 3);
  ctx.stroke();
  ctx.setLineDash([]);

  ctx.fillStyle = '#78909c';
  ctx.fillRect(roadEnd, groundY - 6, 40, 6);
  ctx.setLineDash([6, 6]);
  ctx.beginPath();
  ctx.moveTo(roadEnd, groundY - 3);
  ctx.lineTo(roadEnd + 40, groundY - 3);
  ctx.stroke();
  ctx.setLineDash([]);

  ctx.fillStyle = '#37474f';
  ctx.fillRect(roadStart, groundY - 6, roadEnd - roadStart, 6);
  ctx.fillStyle = '#263238';
  ctx.fillRect(roadStart, groundY - 4, roadEnd - roadStart, 4);

  ctx.fillStyle = '#ffd600';
  for (var lx = roadStart; lx < roadEnd; lx += 40) {
    ctx.fillRect(lx, groundY - 3, 20, 1.5);
  }

  ctx.fillStyle = '#b0bec5';
  ctx.fillRect(roadStart - 3, groundY - 10, 3, 10);
  ctx.fillRect(roadEnd, groundY - 10, 3, 10);

  if (!platform2D.isDriver) {
    ctx.fillStyle = 'rgba(255,255,255,0.75)';
    for (var px = roadStart + 15; px < roadEnd - 15; px += 20) {
      ctx.fillRect(px, groundY - 28, 10, 22);
    }
  }

  var tl = platform2D.trafficLight;
  var tlX = tl.x - camX;
  if (tlX > -30 && tlX < w + 30) {
    ctx.fillStyle = '#455a64';
    ctx.fillRect(tlX - 3, groundY - 85, 6, 85);
    ctx.fillStyle = '#263238';
    ctx.fillRect(tlX - 14, groundY - 110, 28, 65);
    ctx.strokeStyle = '#455a64';
    ctx.lineWidth = 1;
    ctx.strokeRect(tlX - 14, groundY - 110, 28, 65);
    ctx.fillStyle = tl.state === 'red' ? '#ff1744' : '#4a0000';
    ctx.shadowColor = tl.state === 'red' ? '#ff1744' : 'transparent';
    ctx.shadowBlur = tl.state === 'red' ? 12 : 0;
    ctx.beginPath(); ctx.arc(tlX, groundY - 98, 7, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = tl.state === 'yellow' ? '#ffd600' : '#4a4000';
    ctx.shadowColor = tl.state === 'yellow' ? '#ffd600' : 'transparent';
    ctx.shadowBlur = tl.state === 'yellow' ? 12 : 0;
    ctx.beginPath(); ctx.arc(tlX, groundY - 82, 7, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = tl.state === 'green' ? '#00e676' : '#004a00';
    ctx.shadowColor = tl.state === 'green' ? '#00e676' : 'transparent';
    ctx.shadowBlur = tl.state === 'green' ? 12 : 0;
    ctx.beginPath(); ctx.arc(tlX, groundY - 66, 7, 0, Math.PI*2); ctx.fill();
    ctx.shadowBlur = 0;
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 9px monospace';
    ctx.textAlign = 'center';
    var stateText = tl.state === 'red' ? 'ALTO' : (tl.state === 'green' ? 'AVANZA' : 'PRECAUCIÓN');
    ctx.fillText(stateText, tlX, groundY - 48);
  }

  if (platform2D.isDriver && tl.hasStopSign) {
    var stopX = tl.stopSignX - camX;
    if (stopX > -30 && stopX < w + 30) {
      ctx.fillStyle = '#78909c';
      ctx.fillRect(stopX - 2, groundY - 55, 4, 55);
      ctx.fillStyle = '#c62828';
      ctx.beginPath();
      var octSize = 14;
      for (var i = 0; i < 8; i++) {
        var angle = i * Math.PI / 4 - Math.PI / 8;
        var ox = stopX + Math.cos(angle) * octSize;
        var oy = groundY - 65 + Math.sin(angle) * octSize;
        if (i === 0) ctx.moveTo(ox, oy);
        else ctx.lineTo(ox, oy);
      }
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = '#fff';
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 7px Arial';
      ctx.textAlign = 'center';
      ctx.fillText('ALTO', stopX, groundY - 62);
    }
  }

  platform2D.cars.forEach(function(car) {
    var cx = car.x - camX;
    if (cx > -80 && cx < w + 80) {
      ctx.fillStyle = 'rgba(0,0,0,0.2)';
      ctx.beginPath();
      ctx.ellipse(cx + car.w/2, groundY, car.w/2, 3, 0, 0, Math.PI*2);
      ctx.fill();
      ctx.fillStyle = car.color;
      ctx.fillRect(cx + 2, car.y + 2, car.w - 4, car.h - 4);
      ctx.fillStyle = 'rgba(0,0,0,0.15)';
      ctx.fillRect(cx + 2, car.y + car.h - 6, car.w - 4, 4);
      ctx.fillStyle = '#81d4fa';
      ctx.fillRect(cx + 8, car.y + 4, car.w - 16, 7);
      ctx.fillStyle = 'rgba(255,255,255,0.3)';
      ctx.fillRect(cx + 10, car.y + 5, car.w - 20, 3);
      ctx.fillStyle = '#212121';
      ctx.fillRect(cx + 6, car.y + car.h - 3, 10, 3);
      ctx.fillRect(cx + car.w - 16, car.y + car.h - 3, 10, 3);
      ctx.fillStyle = '#fff176';
      if (car.vx > 0) {
        ctx.fillRect(cx + car.w - 3, car.y + 6, 3, 5);
        ctx.fillStyle = '#ff1744';
        ctx.fillRect(cx, car.y + 6, 2, 5);
      } else {
        ctx.fillRect(cx, car.y + 6, 3, 5);
        ctx.fillStyle = '#ff1744';
        ctx.fillRect(cx + car.w - 2, car.y + 6, 2, 5);
      }
    }
  });

  var finishX = platform2D.finishX - camX;
  if (finishX > -40 && finishX < w + 40) {
    ctx.fillStyle = '#bdbdbd';
    ctx.fillRect(finishX, groundY - 55, 5, 55);
    ctx.fillStyle = '#ffd600';
    ctx.beginPath();
    ctx.moveTo(finishX + 5, groundY - 55);
    ctx.lineTo(finishX + 35, groundY - 48);
    ctx.lineTo(finishX + 5, groundY - 41);
    ctx.fill();
    ctx.strokeStyle = '#ff8f00';
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.fillStyle = '#ffd600';
    ctx.font = 'bold 10px "Press Start 2P", monospace';
    ctx.textAlign = 'center';
    ctx.fillText('META', finishX + 18, groundY - 58);
  }

  var p = platform2D.player;
  var px = p.x - camX;
  var py = p.y;

  ctx.fillStyle = 'rgba(0,0,0,0.25)';
  ctx.beginPath();
  ctx.ellipse(px + p.width/2, groundY, p.width/2 + 2, 4, 0, 0, Math.PI*2);
  ctx.fill();

  if (platform2D.isDriver) {
    ctx.fillStyle = '#1976d2';
    ctx.fillRect(px + 2, py + 2, p.width - 4, p.height - 4);
    ctx.fillStyle = '#1565c0';
    ctx.fillRect(px + 2, py + p.height - 6, p.width - 4, 4);
    ctx.fillStyle = '#81d4fa';
    ctx.fillRect(px + 10, py + 4, p.width - 20, 8);
    ctx.fillStyle = 'rgba(255,255,255,0.3)';
    ctx.fillRect(px + 12, py + 5, p.width - 24, 3);
    ctx.fillStyle = '#212121';
    ctx.fillRect(px + 8, py + p.height - 3, 12, 3);
    ctx.fillRect(px + p.width - 20, py + p.height - 3, 12, 3);
    ctx.fillStyle = '#fff176';
    if (p.facingRight) {
      ctx.fillRect(px + p.width - 4, py + 6, 4, 6);
      ctx.fillStyle = '#ff1744';
      ctx.fillRect(px, py + 6, 2, 6);
    } else {
      ctx.fillRect(px, py + 6, 4, 6);
      ctx.fillStyle = '#ff1744';
      ctx.fillRect(px + p.width - 2, py + 6, 2, 6);
    }
    ctx.fillStyle = '#00e676';
    ctx.font = 'bold 8px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('TÚ', px + p.width/2, py - 4);
  } else {
    // Personaje principal animado (Canvas-drawn)
    var frameInfo = getPlayerSpriteFrame();
    ctx.save();
    if (!p.facingRight) {
      ctx.translate(px + p.width/2, 0);
      ctx.scale(-1, 1);
      ctx.translate(-(px + p.width/2), 0);
    }
    drawAnimatedPlayer(ctx, px, py, p.width, p.height, frameInfo);
    ctx.restore();
  }

  ctx.fillStyle = 'rgba(0,0,0,0.04)';
  for (var sy = 0; sy < h; sy += 3) {
    ctx.fillRect(0, sy, w, 1);
  }

  ctx.fillStyle = 'rgba(0,0,0,0.6)';
  ctx.fillRect(8, 8, 110, 28);
  ctx.strokeStyle = '#2a2a4a';
  ctx.lineWidth = 1;
  ctx.strokeRect(8, 8, 110, 28);
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 9px "Press Start 2P", monospace';
  ctx.textAlign = 'left';
  var tlColor = tl.state === 'red' ? '#ff1744' : (tl.state === 'green' ? '#00e676' : '#ffd600');
  var tlText = tl.state === 'red' ? '🔴 ALTO' : (tl.state === 'green' ? '🟢 AVANZA' : '🟡 PRECAUCIÓN');
  ctx.fillStyle = tlColor;
  ctx.fillText(tlText, 14, 26);

  ctx.fillStyle = 'rgba(0,0,0,0.6)';
  ctx.fillRect(w - 110, 8, 102, 22);
  ctx.strokeStyle = '#2a2a4a';
  ctx.strokeRect(w - 110, 8, 102, 22);
  ctx.fillStyle = '#00d4ff';
  ctx.font = '8px "Press Start 2P", monospace';
  ctx.textAlign = 'center';
  ctx.fillText(platform2D.isDriver ? '🚗 CONDUCTOR' : '🚶 PEATÓN', w - 59, 22);
}

function showPlatform2DOverlay(emoji, title, text, allowRetry) {
  var overlay = document.getElementById('platform2DOverlay');
  if (!overlay) return;
  var emojiEl = document.getElementById('p2dEmoji');
  var titleEl = document.getElementById('p2dTitle');
  var textEl = document.getElementById('p2dText');
  var retryBtn = document.getElementById('p2dRetry');
  var continueBtn = document.getElementById('p2dContinue');
  if (emojiEl) emojiEl.textContent = emoji;
  if (titleEl) titleEl.textContent = title;
  if (textEl) textEl.textContent = text;
  if (retryBtn) retryBtn.style.display = allowRetry ? 'inline-flex' : 'none';
  if (continueBtn) continueBtn.style.display = allowRetry ? 'none' : 'inline-flex';
  if (!allowRetry) {
    platform2D._autoContinue = setTimeout(function() {
      if (platform2D.state === 'won') {
        overlay.classList.remove('active');
        completeLevel();
      }
    }, 3500);
  }
  overlay.classList.add('active');
}

function stopPlatform2D() {
  platform2D.running = false;
  if (platform2D.animId) {
    cancelAnimationFrame(platform2D.animId);
    platform2D.animId = null;
  }
  if (platform2D._autoContinue) {
    clearTimeout(platform2D._autoContinue);
    platform2D._autoContinue = null;
  }
}

document.addEventListener('DOMContentLoaded', function() {
 loadGame();
 var nameInput = document.getElementById('playerNameInput');
 if (nameInput) {
  nameInput.addEventListener('change', function() {
   gameState.playerName = nameInput.value.trim();
   saveGame();
   updateStats();
  });
 }

 document.getElementById('btnPlay').addEventListener('click', function() { showScreen('screenZones'); });
 document.getElementById('btnDemo3D').addEventListener('click', open3DDemo);
 document.getElementById('btnShop').addEventListener('click', function() { showScreen('screenShop'); });
 document.getElementById('btnReset').addEventListener('click', function() {
  if (confirm('¿Reiniciar TODO el progreso?')) {
   gameState = {coins:0,xp:0,playerLevel:1,completedLevels:[],unlockedZones:[0],currentZone:0,currentLevelId:0,equippedChar:'👦',equippedAcc:'',ownedItems:['👦'],playerName:'',playerGender:'male'};
   playerGender = 'male';
   try { localStorage.removeItem('educavial_save'); } catch(e) {}
   updateStats();
   showScreen('screenHome');
  }
 });

 document.getElementById('btnZonesBack').addEventListener('click', function() { showScreen('screenHome'); });
 document.getElementById('btnLevelsBack').addEventListener('click', function() { showScreen('screenZones'); });
 document.getElementById('btnShopBack').addEventListener('click', function() { showScreen('screenHome'); });
 document.getElementById('btnVictoryHome').addEventListener('click', function() { showScreen('screenHome'); });

 document.getElementById('gameCard').addEventListener('click', handleGameClick);
 document.getElementById('screenShop').addEventListener('click', handleShopClick);
 document.getElementById('feedbackBtn').addEventListener('click', closeFeedback);

 updateStats();
});
