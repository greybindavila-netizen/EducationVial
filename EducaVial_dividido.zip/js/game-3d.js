// === VARIABLES DEMO 3D ===
var demo3D = {
  scene: null, camera: null, renderer: null, player: null,
  cars: [], trafficLight: null, lightState: 'red', lightTimer: 0,
  running: false, clock: new THREE.Clock(), joystick: { active: false, dx: 0, dz: 0 },
  playerSpeed: 3.5, roadWidth: 8, sidewalkWidth: 3, finishZ: -18,
  playerZ: 12, actionBtn: false, frame: 0, keys: {}
};

function init3DDemo() {
  if (demo3D.renderer) return;
  var canvas = document.getElementById('demo3DCanvas');
  var w = canvas.parentElement.clientWidth;
  var h = canvas.parentElement.clientHeight;

  demo3D.scene = new THREE.Scene();
  demo3D.scene.background = new THREE.Color(0x87CEEB);
  demo3D.scene.fog = new THREE.Fog(0x87CEEB, 20, 60);

  demo3D.camera = new THREE.PerspectiveCamera(60, w / h, 0.1, 100);
  demo3D.camera.position.set(0, 6, 10);

  demo3D.renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: window.innerWidth > 600, powerPreference: 'high-performance' });
  demo3D.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, window.innerWidth < 600 ? 1.5 : 2));
  demo3D.renderer.setSize(w, h, false);
  demo3D.renderer.shadowMap.enabled = true;

  var ambient = new THREE.AmbientLight(0xffffff, 0.6);
  demo3D.scene.add(ambient);
  var dir = new THREE.DirectionalLight(0xffffff, 0.8);
  dir.position.set(10, 20, 10);
  dir.castShadow = true;
  demo3D.scene.add(dir);

  create3DWorld();
  create3DPlayer();
  setup3DControls();

  window.addEventListener('resize', on3DResize);
}

function create3DWorld() {
  var s = demo3D.scene;

  var grassGeo = new THREE.PlaneGeometry(60, 60);
  var grassMat = new THREE.MeshLambertMaterial({ color: 0x4caf50 });
  var grass = new THREE.Mesh(grassGeo, grassMat);
  grass.rotation.x = -Math.PI / 2;
  grass.receiveShadow = true;
  s.add(grass);

  var roadGeo = new THREE.PlaneGeometry(8, 40);
  var roadMat = new THREE.MeshLambertMaterial({ color: 0x424242 });
  var road = new THREE.Mesh(roadGeo, roadMat);
  road.rotation.x = -Math.PI / 2;
  road.position.y = 0.02;
  road.receiveShadow = true;
  s.add(road);

  for (var i = -18; i <= 18; i += 3) {
    var lineGeo = new THREE.PlaneGeometry(0.3, 1.5);
    var lineMat = new THREE.MeshBasicMaterial({ color: 0xffd600 });
    var line = new THREE.Mesh(lineGeo, lineMat);
    line.rotation.x = -Math.PI / 2;
    line.position.set(0, 0.03, i);
    s.add(line);
  }

  [-6, 6].forEach(function(x) {
    var swGeo = new THREE.PlaneGeometry(3, 40);
    var swMat = new THREE.MeshLambertMaterial({ color: 0x9e9e9e });
    var sw = new THREE.Mesh(swGeo, swMat);
    sw.rotation.x = -Math.PI / 2;
    sw.position.set(x, 0.03, 0);
    sw.receiveShadow = true;
    s.add(sw);

    var curbGeo = new THREE.BoxGeometry(0.3, 0.15, 40);
    var curbMat = new THREE.MeshLambertMaterial({ color: 0x757575 });
    var curb = new THREE.Mesh(curbGeo, curbMat);
    curb.position.set(x > 0 ? x - 1.65 : x + 1.65, 0.075, 0);
    curb.castShadow = true;
    s.add(curb);
  });

  var buildingColors = [0xe57373, 0x64b5f6, 0xffb74d, 0x81c784, 0xba68c8];
  for (var i = 0; i < 10; i++) {
    var bw = 2 + Math.random() * 3;
    var bd = 2 + Math.random() * 3;
    var bh = 3 + Math.random() * 6;
    var bGeo = new THREE.BoxGeometry(bw, bh, bd);
    var bMat = new THREE.MeshLambertMaterial({ color: buildingColors[i % 5] });
    var b = new THREE.Mesh(bGeo, bMat);
    var side = i % 2 === 0 ? -1 : 1;
    b.position.set(side * (10 + Math.random() * 8), bh / 2, -15 + i * 5 + Math.random() * 2);
    b.castShadow = true;
    s.add(b);
  }

  for (var i = 0; i < 8; i++) {
    var trunkGeo = new THREE.CylinderGeometry(0.15, 0.2, 1, 6);
    var trunkMat = new THREE.MeshLambertMaterial({ color: 0x795548 });
    var trunk = new THREE.Mesh(trunkGeo, trunkMat);
    var side = i % 2 === 0 ? -1 : 1;
    trunk.position.set(side * (4 + Math.random() * 3), 0.5, -15 + i * 4 + Math.random() * 2);
    trunk.castShadow = true;
    s.add(trunk);

    var leavesGeo = new THREE.SphereGeometry(0.8, 6, 6);
    var leavesMat = new THREE.MeshLambertMaterial({ color: 0x2e7d32 });
    var leaves = new THREE.Mesh(leavesGeo, leavesMat);
    leaves.position.set(0, 1, 0);
    trunk.add(leaves);
  }

  var poleGeo = new THREE.CylinderGeometry(0.08, 0.08, 4, 8);
  var poleMat = new THREE.MeshLambertMaterial({ color: 0x424242 });
  demo3D.trafficLight = new THREE.Mesh(poleGeo, poleMat);
  demo3D.trafficLight.position.set(5, 2, -5);
  demo3D.trafficLight.castShadow = true;
  s.add(demo3D.trafficLight);

  var boxGeo = new THREE.BoxGeometry(0.6, 1.4, 0.4);
  var boxMat = new THREE.MeshLambertMaterial({ color: 0x212121 });
  var box = new THREE.Mesh(boxGeo, boxMat);
  box.position.set(0, 2, 0);
  demo3D.trafficLight.add(box);

  demo3D.lightRed = new THREE.Mesh(new THREE.SphereGeometry(0.15, 8, 8), new THREE.MeshBasicMaterial({ color: 0x330000 }));
  demo3D.lightRed.position.set(0, 0.4, 0.22);
  box.add(demo3D.lightRed);

  demo3D.lightYellow = new THREE.Mesh(new THREE.SphereGeometry(0.15, 8, 8), new THREE.MeshBasicMaterial({ color: 0x333300 }));
  demo3D.lightYellow.position.set(0, 0, 0.22);
  box.add(demo3D.lightYellow);

  demo3D.lightGreen = new THREE.Mesh(new THREE.SphereGeometry(0.15, 8, 8), new THREE.MeshBasicMaterial({ color: 0x003300 }));
  demo3D.lightGreen.position.set(0, -0.4, 0.22);
  box.add(demo3D.lightGreen);

  demo3D.trafficPoint = new THREE.PointLight(0xff0000, 0, 8);
  demo3D.trafficPoint.position.set(5, 4, -5);
  s.add(demo3D.trafficPoint);

  var finishGeo = new THREE.PlaneGeometry(14, 0.5);
  var finishMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.7 });
  var finish = new THREE.Mesh(finishGeo, finishMat);
  finish.rotation.x = -Math.PI / 2;
  finish.position.set(0, 0.04, demo3D.finishZ);
  s.add(finish);

  for (var i = -3; i <= 3; i += 1.5) {
    var crossGeo = new THREE.PlaneGeometry(0.8, 3);
    var crossMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.5 });
    var cross = new THREE.Mesh(crossGeo, crossMat);
    cross.rotation.x = -Math.PI / 2;
    cross.position.set(i, 0.04, 0);
    s.add(cross);
  }
}

function create3DPlayer() {
  if (demo3D.player) {
    demo3D.scene.remove(demo3D.player);
  }
  var imgUrl = (typeof getPlayerImg === 'function') ? getPlayerImg() : playerImgMale;
  var texLoader = new THREE.TextureLoader();
  texLoader.load(imgUrl, function(texture) {
    var geo = new THREE.PlaneGeometry(1.2, 1.6);
    var mat = new THREE.MeshBasicMaterial({ map: texture, transparent: true, side: THREE.DoubleSide });
    demo3D.player = new THREE.Mesh(geo, mat);
    demo3D.player.position.set(0, 0.8, demo3D.playerZ);
    demo3D.scene.add(demo3D.player);
  });
}

function create3DCar(z, speed, lane) {
  var carGroup = new THREE.Group();
  var bodyGeo = new THREE.BoxGeometry(1.8, 0.7, 3.5);
  var colors = [0xe53935, 0x1e88e5, 0xfdd835, 0x43a047, 0x8e24aa];
  var bodyMat = new THREE.MeshLambertMaterial({ color: colors[Math.floor(Math.random() * colors.length)] });
  var body = new THREE.Mesh(bodyGeo, bodyMat);
  body.position.y = 0.6;
  body.castShadow = true;
  carGroup.add(body);

  var roofGeo = new THREE.BoxGeometry(1.4, 0.5, 1.8);
  var roofMat = new THREE.MeshLambertMaterial({ color: 0x333333 });
  var roof = new THREE.Mesh(roofGeo, roofMat);
  roof.position.y = 1.2;
  carGroup.add(roof);

  var wheelGeo = new THREE.CylinderGeometry(0.25, 0.25, 0.15, 8);
  var wheelMat = new THREE.MeshLambertMaterial({ color: 0x212121 });
  [[-0.9, 0.25, 1.2], [0.9, 0.25, 1.2], [-0.9, 0.25, -1.2], [0.9, 0.25, -1.2]].forEach(function(pos) {
    var w = new THREE.Mesh(wheelGeo, wheelMat);
    w.rotation.z = Math.PI / 2;
    w.position.set(pos[0], pos[1], pos[2]);
    carGroup.add(w);
  });

  var lightGeo = new THREE.SphereGeometry(0.12, 6, 6);
  var lightMat = new THREE.MeshBasicMaterial({ color: 0xffffcc });
  [[-0.5, 0.7, 1.8], [0.5, 0.7, 1.8]].forEach(function(pos) {
    var l = new THREE.Mesh(lightGeo, lightMat);
    l.position.set(pos[0], pos[1], pos[2]);
    carGroup.add(l);
  });

  carGroup.position.set(lane, 0, z);
  demo3D.scene.add(carGroup);
  return { mesh: carGroup, speed: speed, lane: lane };
}

function setup3DControls() {
  document.addEventListener('keydown', function(e) {
    demo3D.keys[e.key.toLowerCase()] = true;
    if (e.key === ' ' || e.key === 'ArrowUp') demo3D.actionBtn = true;
  });
  document.addEventListener('keyup', function(e) {
    demo3D.keys[e.key.toLowerCase()] = false;
    if (e.key === ' ' || e.key === 'ArrowUp') demo3D.actionBtn = false;
  });

  var joy = document.getElementById('demo3DJoystick');
  var knob = document.getElementById('demo3DKnob');
  if (!joy || !knob) return;
  joy.classList.add('active');

  var joyRect, centerX, centerY, maxDist = 35;

  function startJoy(e) {
    e.preventDefault();
    joyRect = joy.getBoundingClientRect();
    centerX = joyRect.left + joyRect.width / 2;
    centerY = joyRect.top + joyRect.height / 2;
    demo3D.joystick.active = true;
    moveJoy(e);
  }
  function moveJoy(e) {
    if (!demo3D.joystick.active) return;
    e.preventDefault();
    var touch = e.touches ? e.touches[0] : e;
    var dx = touch.clientX - centerX;
    var dy = touch.clientY - centerY;
    var dist = Math.sqrt(dx * dx + dy * dy);
    if (dist > maxDist) { dx = dx / dist * maxDist; dy = dy / dist * maxDist; }
    knob.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
    demo3D.joystick.dx = dx / maxDist;
    demo3D.joystick.dz = dy / maxDist;
  }
  function endJoy(e) {
    e.preventDefault();
    demo3D.joystick.active = false;
    demo3D.joystick.dx = 0;
    demo3D.joystick.dz = 0;
    knob.style.transform = 'translate(0,0)';
  }

  joy.addEventListener('touchstart', startJoy, {passive: false});
  joy.addEventListener('touchmove', moveJoy, {passive: false});
  joy.addEventListener('touchend', endJoy, {passive: false});

  var actionBtn = document.getElementById('demo3DActionBtn');
  if (actionBtn) {
    actionBtn.classList.add('active');
    actionBtn.addEventListener('touchstart', function(e) { e.preventDefault(); demo3D.actionBtn = true; }, {passive: false});
    actionBtn.addEventListener('touchend', function(e) { e.preventDefault(); demo3D.actionBtn = false; }, {passive: false});
  }
}

function update3DTrafficLight() {
  demo3D.frame++;
  var phase = demo3D.frame % 600;
  var state = 'red';
  if (phase < 240) state = 'red';
  else if (phase < 480) state = 'green';
  else state = 'yellow';

  if (state !== demo3D.lightState) {
    demo3D.lightState = state;
    demo3D.lightRed.material.color.setHex(state === 'red' ? 0xff0000 : 0x330000);
    demo3D.lightYellow.material.color.setHex(state === 'yellow' ? 0xffd600 : 0x333300);
    demo3D.lightGreen.material.color.setHex(state === 'green' ? 0x00ff00 : 0x003300);
    if (state === 'red') { demo3D.trafficPoint.color.setHex(0xff0000); demo3D.trafficPoint.intensity = 1.5; }
    else if (state === 'yellow') { demo3D.trafficPoint.color.setHex(0xffd600); demo3D.trafficPoint.intensity = 1; }
    else { demo3D.trafficPoint.color.setHex(0x00ff00); demo3D.trafficPoint.intensity = 1.5; }
  }
}

function update3DGame() {
  if (!demo3D.running || !demo3D.player) return;
  var dt = demo3D.clock.getDelta();
  demo3D.frame++;

  var moveX = 0, moveZ = 0;
  if (demo3D.keys['w'] || demo3D.keys['arrowup']) moveZ -= 1;
  if (demo3D.keys['s'] || demo3D.keys['arrowdown']) moveZ += 1;
  if (demo3D.keys['a'] || demo3D.keys['arrowleft']) moveX -= 1;
  if (demo3D.keys['d'] || demo3D.keys['arrowright']) moveX += 1;

  if (demo3D.joystick.active) {
    moveX += demo3D.joystick.dx;
    moveZ += demo3D.joystick.dz;
  }

  var len = Math.sqrt(moveX * moveX + moveZ * moveZ);
  if (len > 1) { moveX /= len; moveZ /= len; }

  var newX = demo3D.player.position.x + moveX * demo3D.playerSpeed * dt;
  var newZ = demo3D.player.position.z + moveZ * demo3D.playerSpeed * dt;
  newX = Math.max(-7, Math.min(7, newX));
  newZ = Math.max(-20, Math.min(15, newZ));
  demo3D.player.position.x = newX;
  demo3D.player.position.z = newZ;

  demo3D.player.lookAt(demo3D.camera.position.x, demo3D.player.position.y, demo3D.camera.position.z);

  var camX = demo3D.player.position.x * 0.3;
  var camZ = demo3D.player.position.z + 8;
  var camY = 6 + Math.sin(demo3D.frame * 0.02) * 0.1;
  demo3D.camera.position.x += (camX - demo3D.camera.position.x) * 0.1;
  demo3D.camera.position.z += (camZ - demo3D.camera.position.z) * 0.1;
  demo3D.camera.position.y = camY;
  demo3D.camera.lookAt(demo3D.player.position.x, 1, demo3D.player.position.z);

  if (demo3D.cars.length < 3 && Math.random() < 0.008) {
    var lane = Math.random() < 0.5 ? -2.5 : 2.5;
    var startZ = lane < 0 ? -25 : 25;
    var speed = lane < 0 ? (3 + Math.random() * 2) : -(3 + Math.random() * 2);
    demo3D.cars.push(create3DCar(startZ, speed, lane));
  }

  for (var i = demo3D.cars.length - 1; i >= 0; i--) {
    var car = demo3D.cars[i];
    car.mesh.position.z += car.speed * dt;
    var dx = car.mesh.position.x - demo3D.player.position.x;
    var dz = car.mesh.position.z - demo3D.player.position.z;
    var dist = Math.sqrt(dx * dx + dz * dz);
    if (dist < 1.8) {
      end3DLevel(false, '¡Un auto te golpeo! Solo cruza cuando el semaforo este verde y no haya autos cerca.');
      return;
    }
    if (car.mesh.position.z > 30 || car.mesh.position.z < -30) {
      demo3D.scene.remove(car.mesh);
      demo3D.cars.splice(i, 1);
    }
  }

  if (demo3D.player.position.z <= demo3D.finishZ) {
    end3DLevel(true, '¡Excelente! Cruzaste la calle con seguridad. Siempre espera el semaforo verde y mira ambos lados.');
    return;
  }

  update3DTrafficLight();
  demo3D.renderer.render(demo3D.scene, demo3D.camera);
  if (demo3D.running) requestAnimationFrame(update3DGame);
}

function start3DLevel() {
  document.getElementById('demo3DMsg').classList.remove('active');
  if (demo3D.player) demo3D.player.position.set(0, 0.8, demo3D.playerZ);
  demo3D.cars.forEach(function(car) { demo3D.scene.remove(car.mesh); });
  demo3D.cars = [];
  demo3D.running = true;
  demo3D.clock = new THREE.Clock();
  demo3D.frame = 0;
  update3DGame();
}

function end3DLevel(win, msg) {
  demo3D.running = false;
  var msgEl = document.getElementById('demo3DMsg');
  var titleEl = document.getElementById('demo3DMsgTitle');
  var textEl = document.getElementById('demo3DMsgText');
  var btnEl = document.getElementById('demo3DMsgBtn');
  titleEl.textContent = win ? '⭐ ¡GANASTE!' : '💥 ¡CUIDADO!';
  titleEl.style.color = win ? '#00ff88' : '#ff1744';
  textEl.textContent = msg;
  btnEl.textContent = win ? '▶️ Otra vez' : '🔄 Reintentar';
  msgEl.classList.add('active');
  if (win) {
    gameState.coins += 15;
    gameState.xp += 25;
    if (gameState.xp >= gameState.playerLevel * 50) { gameState.playerLevel++; gameState.xp = 0; }
    saveGame();
    updateStats();
  }
}

function exit3DDemo() {
  demo3D.running = false;
  document.getElementById('screen3DDemo').classList.remove('active');
  showScreen('screenHome');
}

function on3DResize() {
  if (!demo3D.renderer) return;
  var canvas = document.getElementById('demo3DCanvas');
  var w = canvas.parentElement.clientWidth;
  var h = canvas.parentElement.clientHeight;
  demo3D.camera.aspect = w / h;
  demo3D.camera.updateProjectionMatrix();
  demo3D.renderer.setSize(w, h, false);
}

function open3DDemo() {
  init3DDemo();
  document.querySelectorAll('.screen').forEach(function(el) { el.classList.remove('active'); });
  document.getElementById('screen3DDemo').classList.add('active');
  var msgEl = document.getElementById('demo3DMsg');
  document.getElementById('demo3DMsgTitle').textContent = '🎮 DEMO 3D';
  document.getElementById('demo3DMsgTitle').style.color = '#00d4ff';
  document.getElementById('demo3DMsgText').textContent = 'Usa WASD o el joystick para moverte. Cruza la calle cuando el semaforo este verde. ¡Cuidado con los autos!';
  document.getElementById('demo3DMsgBtn').textContent = '▶️ Empezar';
  msgEl.classList.add('active');
  on3DResize();
}


// === MAPA 3D DE NIVELES ===
var levels3D = {
  scene: null, camera: null, renderer: null, player: null,
  nodes: [], running: false, clock: new THREE.Clock(),
  joystick: { active: false, dx: 0, dz: 0 }, keys: {},
  playerSpeed: 4, selectedLevel: null, frame: 0
};

function initLevels3D() {
  if (levels3D.renderer) return;
  var canvas = document.getElementById('levels3DCanvas');
  var w = canvas.parentElement.clientWidth;
  var h = canvas.parentElement.clientHeight;

  levels3D.scene = new THREE.Scene();
  levels3D.scene.background = new THREE.Color(0x87CEEB);
  levels3D.scene.fog = new THREE.Fog(0x87CEEB, 25, 70);

  levels3D.camera = new THREE.PerspectiveCamera(55, w / h, 0.1, 100);
  levels3D.camera.position.set(0, 10, 15);

  levels3D.renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: window.innerWidth > 600, powerPreference: 'high-performance' });
  levels3D.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, window.innerWidth < 600 ? 1.5 : 2));
  levels3D.renderer.setSize(w, h, false);
  levels3D.renderer.shadowMap.enabled = true;

  var ambient = new THREE.AmbientLight(0xffffff, 0.5);
  levels3D.scene.add(ambient);
  var dir = new THREE.DirectionalLight(0xffffff, 0.7);
  dir.position.set(15, 25, 10);
  dir.castShadow = true;
  levels3D.scene.add(dir);

  createLevels3DWorld();
  createLevels3DPlayer();
  createLevelNodes();
  setupLevels3DControls();

  window.addEventListener('resize', onLevels3DResize);
}

function createLevels3DWorld() {
  var s = levels3D.scene;

  // Suelo
  var grassGeo = new THREE.PlaneGeometry(80, 80);
  var grassMat = new THREE.MeshLambertMaterial({ color: 0x4caf50 });
  var grass = new THREE.Mesh(grassGeo, grassMat);
  grass.rotation.x = -Math.PI / 2;
  grass.receiveShadow = true;
  s.add(grass);

  // Calles principales
  var roadPaths = [
    {x:0,z:0,w:8,h:50},   // vertical central
    {x:0,z:-15,w:50,h:8}, // horizontal arriba
    {x:0,z:0,w:50,h:8},   // horizontal centro
    {x:0,z:15,w:50,h:8},  // horizontal abajo
  ];

  roadPaths.forEach(function(r) {
    var roadGeo = new THREE.PlaneGeometry(r.w, r.h);
    var roadMat = new THREE.MeshLambertMaterial({ color: 0x424242 });
    var road = new THREE.Mesh(roadGeo, roadMat);
    road.rotation.x = -Math.PI / 2;
    road.position.set(r.x, 0.02, r.z);
    road.receiveShadow = true;
    s.add(road);

    // Líneas
    if (r.w > r.h) { // horizontal
      for (var i = -r.w/2 + 2; i < r.w/2; i += 3) {
        var lineGeo = new THREE.PlaneGeometry(1.5, 0.3);
        var lineMat = new THREE.MeshBasicMaterial({ color: 0xffd600 });
        var line = new THREE.Mesh(lineGeo, lineMat);
        line.rotation.x = -Math.PI / 2;
        line.position.set(i, 0.03, r.z);
        s.add(line);
      }
    } else { // vertical
      for (var i = -r.h/2 + 2; i < r.h/2; i += 3) {
        var lineGeo = new THREE.PlaneGeometry(0.3, 1.5);
        var lineMat = new THREE.MeshBasicMaterial({ color: 0xffd600 });
        var line = new THREE.Mesh(lineGeo, lineMat);
        line.rotation.x = -Math.PI / 2;
        line.position.set(r.x, 0.03, i);
        s.add(line);
      }
    }
  });

  // Aceras
  [[-6, 0, 50, 8], [6, 0, 50, 8], [0, -19, 8, 50], [0, 19, 8, 50]].forEach(function(sw) {
    var swGeo = new THREE.PlaneGeometry(sw[2], sw[3]);
    var swMat = new THREE.MeshLambertMaterial({ color: 0x9e9e9e });
    var sidewalk = new THREE.Mesh(swGeo, swMat);
    sidewalk.rotation.x = -Math.PI / 2;
    sidewalk.position.set(sw[0], 0.03, sw[1]);
    s.add(sidewalk);
  });

  // Edificios
  var colors = [0xe57373, 0x64b5f6, 0xffb74d, 0x81c784, 0xba68c8, 0x90a4ae];
  for (var i = 0; i < 16; i++) {
    var bw = 2.5 + Math.random() * 3;
    var bd = 2.5 + Math.random() * 3;
    var bh = 4 + Math.random() * 8;
    var bGeo = new THREE.BoxGeometry(bw, bh, bd);
    var bMat = new THREE.MeshLambertMaterial({ color: colors[i % 6] });
    var b = new THREE.Mesh(bGeo, bMat);
    var angle = (i / 16) * Math.PI * 2;
    var radius = 18 + Math.random() * 8;
    b.position.set(Math.cos(angle) * radius, bh / 2, Math.sin(angle) * radius);
    b.castShadow = true;
    s.add(b);
  }

  // Árboles
  for (var i = 0; i < 12; i++) {
    var trunkGeo = new THREE.CylinderGeometry(0.2, 0.25, 1.2, 6);
    var trunkMat = new THREE.MeshLambertMaterial({ color: 0x795548 });
    var trunk = new THREE.Mesh(trunkGeo, trunkMat);
    var angle = (i / 12) * Math.PI * 2 + 0.5;
    var radius = 10 + Math.random() * 6;
    trunk.position.set(Math.cos(angle) * radius, 0.6, Math.sin(angle) * radius);
    trunk.castShadow = true;
    s.add(trunk);

    var leavesGeo = new THREE.SphereGeometry(1, 6, 6);
    var leavesMat = new THREE.MeshLambertMaterial({ color: 0x2e7d32 });
    var leaves = new THREE.Mesh(leavesGeo, leavesMat);
    leaves.position.set(0, 1.2, 0);
    trunk.add(leaves);
  }

  // Semáforos decorativos
  [[5, -15], [-5, 0], [5, 15]].forEach(function(pos) {
    var poleGeo = new THREE.CylinderGeometry(0.08, 0.08, 4, 8);
    var poleMat = new THREE.MeshLambertMaterial({ color: 0x424242 });
    var pole = new THREE.Mesh(poleGeo, poleMat);
    pole.position.set(pos[0], 2, pos[1]);
    s.add(pole);

    var boxGeo = new THREE.BoxGeometry(0.5, 1.2, 0.3);
    var boxMat = new THREE.MeshLambertMaterial({ color: 0x212121 });
    var box = new THREE.Mesh(boxGeo, boxMat);
    box.position.set(0, 1.5, 0);
    pole.add(box);

    var red = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 8), new THREE.MeshBasicMaterial({ color: 0xff0000 }));
    red.position.set(0, 0.3, 0.16); box.add(red);
    var yellow = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 8), new THREE.MeshBasicMaterial({ color: 0xffd600 }));
    yellow.position.set(0, 0, 0.16); box.add(yellow);
    var green = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 8), new THREE.MeshBasicMaterial({ color: 0x00ff00 }));
    green.position.set(0, -0.3, 0.16); box.add(green);
  });
}

function createLevels3DPlayer() {
  if (levels3D.player) {
    levels3D.scene.remove(levels3D.player);
  }
  var imgUrl = (typeof getPlayerImg === 'function') ? getPlayerImg() : (typeof playerImgMale !== 'undefined' ? playerImgMale : '');
  if (!imgUrl) return;

  var texLoader = new THREE.TextureLoader();
  texLoader.load(imgUrl, function(texture) {
    var geo = new THREE.PlaneGeometry(1, 1.4);
    var mat = new THREE.MeshBasicMaterial({ map: texture, transparent: true, side: THREE.DoubleSide });
    levels3D.player = new THREE.Mesh(geo, mat);
    levels3D.player.position.set(0, 0.7, 20);
    levels3D.scene.add(levels3D.player);
  });
}

function createLevelNodes() {
  var zone = zones[gameState.currentZone];
  if (!zone) return;

  // Posiciones en la ciudad para 15 niveles
  var positions = [
    {x:-18,z:-18}, {x:-10,z:-18}, {x:-2,z:-18}, {x:6,z:-18}, {x:14,z:-18},
    {x:18,z:-10}, {x:18,z:-2}, {x:18,z:6}, {x:18,z:14}, {x:10,z:18},
    {x:2,z:18}, {x:-6,z:18}, {x:-14,z:18}, {x:-18,z:10}, {x:-18,z:2}
  ];

  zone.levels.forEach(function(level, idx) {
    var globalId = getGlobalLevelId(gameState.currentZone, level.id);
    var isCompleted = gameState.completedLevels.includes(globalId);
    var prevId = globalId - 1;
    var isUnlocked = (idx === 0) || gameState.completedLevels.includes(prevId) || isCompleted;
    var pos = positions[idx] || {x:0, z:0};

    // Base del nodo
    var baseColor = isCompleted ? 0xffd600 : (isUnlocked ? 0x00e676 : 0x616161);
    var baseGeo = new THREE.CylinderGeometry(0.8, 0.9, 0.3, 16);
    var baseMat = new THREE.MeshLambertMaterial({ color: baseColor });
    var base = new THREE.Mesh(baseGeo, baseMat);
    base.position.set(pos.x, 0.15, pos.z);
    base.castShadow = true;
    levels3D.scene.add(base);

    // Poste con número
    var poleGeo = new THREE.CylinderGeometry(0.05, 0.05, 2, 8);
    var poleMat = new THREE.MeshLambertMaterial({ color: 0x757575 });
    var pole = new THREE.Mesh(poleGeo, poleMat);
    pole.position.set(pos.x, 1, pos.z);
    levels3D.scene.add(pole);

    // Esfera indicadora
    var sphereGeo = new THREE.SphereGeometry(0.4, 12, 12);
    var sphereMat = new THREE.MeshLambertMaterial({ color: baseColor, emissive: baseColor, emissiveIntensity: 0.3 });
    var sphere = new THREE.Mesh(sphereGeo, sphereMat);
    sphere.position.set(pos.x, 2.1, pos.z);
    levels3D.scene.add(sphere);

    // Guardar referencia
    levels3D.nodes.push({
      level: level, idx: idx, globalId: globalId,
      isUnlocked: isUnlocked, isCompleted: isCompleted,
      position: new THREE.Vector3(pos.x, 0, pos.z),
      base: base, sphere: sphere
    });
  });
}

function setupLevels3DControls() {
  document.addEventListener('keydown', function(e) {
    levels3D.keys[e.key.toLowerCase()] = true;
  });
  document.addEventListener('keyup', function(e) {
    levels3D.keys[e.key.toLowerCase()] = false;
  });

  var joy = document.getElementById('levels3DJoystick');
  var knob = document.getElementById('levels3DKnob');
  if (!joy || !knob) return;

  // Mostrar joystick en móvil
  if ('ontouchstart' in window) {
    joy.classList.add('active');
  }

  var joyRect, centerX, centerY, maxDist = 35;

  function startJoy(e) {
    e.preventDefault();
    joyRect = joy.getBoundingClientRect();
    centerX = joyRect.left + joyRect.width / 2;
    centerY = joyRect.top + joyRect.height / 2;
    levels3D.joystick.active = true;
    moveJoy(e);
  }
  function moveJoy(e) {
    if (!levels3D.joystick.active) return;
    e.preventDefault();
    var touch = e.touches ? e.touches[0] : e;
    var dx = touch.clientX - centerX;
    var dy = touch.clientY - centerY;
    var dist = Math.sqrt(dx * dx + dy * dy);
    if (dist > maxDist) { dx = dx / dist * maxDist; dy = dy / dist * maxDist; }
    knob.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
    levels3D.joystick.dx = dx / maxDist;
    levels3D.joystick.dz = dy / maxDist;
  }
  function endJoy(e) {
    e.preventDefault();
    levels3D.joystick.active = false;
    levels3D.joystick.dx = 0;
    levels3D.joystick.dz = 0;
    knob.style.transform = 'translate(0,0)';
  }

  joy.addEventListener('touchstart', startJoy, {passive: false});
  joy.addEventListener('touchmove', moveJoy, {passive: false});
  joy.addEventListener('touchend', endJoy, {passive: false});
}

function updateLevels3DMap() {
  if (!levels3D.running || !levels3D.player) return;
  var dt = levels3D.clock.getDelta();
  levels3D.frame++;

  var moveX = 0, moveZ = 0;
  if (levels3D.keys['w'] || levels3D.keys['arrowup']) moveZ -= 1;
  if (levels3D.keys['s'] || levels3D.keys['arrowdown']) moveZ += 1;
  if (levels3D.keys['a'] || levels3D.keys['arrowleft']) moveX -= 1;
  if (levels3D.keys['d'] || levels3D.keys['arrowright']) moveX += 1;

  if (levels3D.joystick.active) {
    moveX += levels3D.joystick.dx;
    moveZ += levels3D.joystick.dz;
  }

  var len = Math.sqrt(moveX * moveX + moveZ * moveZ);
  if (len > 1) { moveX /= len; moveZ /= len; }

  var newX = levels3D.player.position.x + moveX * levels3D.playerSpeed * dt;
  var newZ = levels3D.player.position.z + moveZ * levels3D.playerSpeed * dt;
  newX = Math.max(-35, Math.min(35, newX));
  newZ = Math.max(-35, Math.min(35, newZ));
  levels3D.player.position.x = newX;
  levels3D.player.position.z = newZ;

  // Billboard
  levels3D.player.lookAt(levels3D.camera.position.x, levels3D.player.position.y, levels3D.camera.position.z);

  // Cámara sigue al jugador
  var camX = levels3D.player.position.x * 0.4;
  var camZ = levels3D.player.position.z + 12;
  var camY = 10 + Math.sin(levels3D.frame * 0.015) * 0.3;
  levels3D.camera.position.x += (camX - levels3D.camera.position.x) * 0.08;
  levels3D.camera.position.z += (camZ - levels3D.camera.position.z) * 0.08;
  levels3D.camera.position.y = camY;
  levels3D.camera.lookAt(levels3D.player.position.x, 0, levels3D.player.position.z);

  // Animar nodos
  levels3D.nodes.forEach(function(node) {
    if (node.sphere) {
      node.sphere.position.y = 2.1 + Math.sin(levels3D.frame * 0.03 + node.idx) * 0.15;
      node.sphere.rotation.y += 0.01;
    }
  });

  // Detectar cercanía a nodos
  var playerPos = levels3D.player.position;
  var closest = null;
  var closestDist = 999;

  levels3D.nodes.forEach(function(node) {
    var dx = node.position.x - playerPos.x;
    var dz = node.position.z - playerPos.z;
    var dist = Math.sqrt(dx * dx + dz * dz);
    if (dist < closestDist) {
      closestDist = dist;
      closest = node;
    }
    // Efecto de hover
    if (node.sphere) {
      var scale = dist < 2.5 ? 1.3 : 1;
      node.sphere.scale.setScalar(node.sphere.scale.x + (scale - node.sphere.scale.x) * 0.1);
    }
  });

  // Si está cerca de un nodo desbloqueado, mostrar mensaje
  var msgEl = document.getElementById('levels3DMsg');
  if (closest && closestDist < 2.5 && closest.isUnlocked && !msgEl.classList.contains('active')) {
    levels3D.selectedLevel = closest;
    document.getElementById('levels3DMsgTitle').textContent = 'NIVEL ' + closest.level.id;
    document.getElementById('levels3DMsgText').textContent = closest.level.title;
    msgEl.classList.add('active');
  } else if ((closestDist >= 3.5 || !closest.isUnlocked) && msgEl.classList.contains('active')) {
    msgEl.classList.remove('active');
    levels3D.selectedLevel = null;
  }

  levels3D.renderer.render(levels3D.scene, levels3D.camera);
  if (levels3D.running) requestAnimationFrame(updateLevels3DMap);
}

function enterLevelFromMap() {
  if (!levels3D.selectedLevel) return;
  var level = levels3D.selectedLevel.level;
  levels3D.running = false;
  var msgEl = document.getElementById('levels3DMsg');
  if (msgEl) msgEl.classList.remove('active');
  startLevel(level);
}

function closeLevelMapMsg() {
  document.getElementById('levels3DMsg').classList.remove('active');
  levels3D.selectedLevel = null;
}

function onLevels3DResize() {
  if (!levels3D.renderer) return;
  var canvas = document.getElementById('levels3DCanvas');
  var w = canvas.parentElement.clientWidth;
  var h = canvas.parentElement.clientHeight;
  levels3D.camera.aspect = w / h;
  levels3D.camera.updateProjectionMatrix();
  levels3D.renderer.setSize(w, h, false);
}
